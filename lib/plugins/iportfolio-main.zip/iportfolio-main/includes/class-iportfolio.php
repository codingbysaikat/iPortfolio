<?php
defined( 'ABSPATH' ) || exit;

class My_Plugin {

    public function __construct() {
        // Constructor logic if needed
    }

    public function run() {
        // Hook into WordPress
        add_action( 'init', [ $this, 'register_custom_post_type' ] );
        add_action( 'init', [ $this, 'register_taxonomies' ] );
        //add_action( 'init', [ $this, 'insert_default_terms' ] );

    }

    public function register_custom_post_type() {
        register_post_type( 'Portfolio', [
            'labels' => [
                     'name'               => 'Portfolios',
                     'singular_name'      => 'Portfolio',
                     'add_new'            => 'Add Portfolio',
                     'add_new_item'       => 'Add New Portfolio',
                     'edit_item'          => 'Edit Portfolio',
                     'new_item'           => 'New Portfolio',
                     'view_item'          => 'View Portfolio',
                     'search_items'       => 'Search Portfolios',
                     'not_found'          => 'No portfolios found',
                     'not_found_in_trash' => 'No portfolios found in Trash',
                     'all_items'          => 'All Portfolios',
                     'menu_name'          => 'Portfolio',
                     'name_admin_bar'     => 'Portfolio',
              ],
            'public'              => true,
            'show_ui'             => true,
            'show_in_menu'        => true,
            'query_var'           => true,
            'menu_position'       => 5,
            'menu_icon'           => 'dashicons-portfolio',
            'supports'            => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'),
            'has_archive'         => true,
            'hierarchical'        => false,
            'rewrite'             => array('slug' => 'portfolio'),
            'show_in_rest'        => true, 
            'capability_type'     => 'post',
            'taxonomies'          => array('portfolio_category'), 
        ] );
    }

    public function register_taxonomies() {
        $labels = array(
            'name'              => __( 'Portfolios Categories' ),
            'singular_name'     => __( 'Portfolios Category' ),
            'search_items'      => __( 'Search Portfolios Categories' ),
            'all_items'         => __( 'All Portfolios Categories' ),
            'parent_item'       => __( 'Parent Portfolios Category' ),
            'edit_item'         => __( 'Edit Portfolios Category' ),
            'update_item'       => __( 'Update Portfolios Category' ),
            'add_new_item'      => __( 'Add New Portfolios Category' ),
            'new_item_name'     => __( 'New Portfolios Category Name' ),
            'menu_name'         => __( 'Portfolios Categories' ),
        );

        $args = array(
            'labels'            => $labels,
            'hierarchical'      => true,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array( 'slug' => 'portfolios_category' ),
            'show_in_rest'      => true,
        );

        register_taxonomy( 'portfolios_category', array( 'portfolio' ), $args );
    }
}
