<?php
/**
 * Plugin Name: iPortfolio Main
 * Description: iPortfolio mian plugin helps for more functions and featured
 * Version: 1.0
 * Author: saikat mondal
 */

defined( 'ABSPATH' ) || exit;

// Load main class
require_once plugin_dir_path( __FILE__ ) . 'includes/class-iportfolio.php';
// Initialize the plugin
function iportfolio_plugin_run() {
    $plugin = new My_Plugin();
    $plugin->run();
}
add_action( 'plugins_loaded', 'iportfolio_plugin_run' );

